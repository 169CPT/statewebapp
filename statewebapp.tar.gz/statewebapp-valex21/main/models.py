from __future__ import unicode_literals
import datetime

from django.db import models
from main.assortedfunctions import validpwd

# Create your models here.

class Voter(models.Model):
    COUNTY_LIST_CHOICES = (
        ("fr", "Freedom"), 
        ("sm", "Smelly"), 
        ("gn", "Gnarly"),
        ("bw", "Big Wednesday"), 
        ("st", "Sountrack"),
        ("bcs", "Boy Called Sue"),
        ("in", "Infamy")
        )
    STATE_LIST_CHOICES = (
        ("NC", "Norht Carolina"),
        ("SC", "South Carolina"),
        ("WY", "Wyoming")
        )
    CITY_LIST_CHOICES = (
        ("Upton", "Upton"),
        ("Liverpool", "Liverpool"), 
        ("Claxer", "Claxer"),
        ("Sienna","Sienna")
        )
    GENDER_CHOICES = (
        ("M", "Male"),
        ("m", "Male"),
        ("f", "Female"),
        ("F", "Female")
        )
    first_name = models.CharField(max_length=40, verbose_name = "Voter's first name", blank=False)
    last_name = models.CharField(max_length=40, verbose_name = "Voter's last name", blank=False)
    dob = models.DateField(verbose_name = "Voter's date of birth", blank=False)
    ssnum = models.CharField(max_length=11, verbose_name="Voter's social security number", blank=False)
    # gender = models.CharField(max_length=1, choices=GENDER_CHOICES, verbose_name="Voter's gender/sex", blank=False)
    gender = models.CharField(max_length=1, verbose_name="Voter's gender/sex", blank=False)
    #birthcounty = models.CharField(max_length=40, choices=COUNTY_LIST_CHOICES, verbose_name = "Voter's birth county", blank=False)
    birthcounty = models.CharField(max_length=40, verbose_name = "Voter's birth county", blank=False)
    email = models.EmailField(verbose_name="Voter's email address.  Needed for registration and confirmation", blank=False)
    homestreet = models.CharField(max_length=50, verbose_name="Voter's physical home street address.  No PO BOXes", blank=False)
    #homecity = models.CharField(max_length=50, choices=CITY_LIST_CHOICES, verbose_name="Voter's physical home city address.", blank=False)
    homecity = models.CharField(max_length=50, verbose_name="Voter's physical home city address.", blank=False)
    #homestate = models.CharField(max_length=50, choices=STATE_LIST_CHOICES, verbose_name="Voter's physical home state address.", blank=False)
    homestate = models.CharField(max_length=50, verbose_name="Voter's physical home state address.", blank=False)
    homezip = models.CharField(max_length=50, verbose_name="Voter's physical home address zip code.", blank=False)
    password = models.CharField(max_length=20, validators=[validpwd], verbose_name="Citizen's password", blank=False)

    comments = models.TextField(verbose_name = "Special Comments registrant makes at time of registration", blank=True)
    regstat = models.BooleanField(verbose_name="Voter's registration status", default=False, blank=False)
    regdate = models.DateField(verbose_name="Date the voter registered.", default=datetime.date.today, blank=False)
    
    
    def _get_full_name(self):
        "Returns a person's full name."
        return '%s %s' % (self.first_name, self.last_name)

    #Add person's full name as a new managed attribute
    full_name = property(_get_full_name)
    
    #Add a "_str_" method to return the full name of the person in UI
    def __str__(self):
        return "{0}".format(self.full_name)