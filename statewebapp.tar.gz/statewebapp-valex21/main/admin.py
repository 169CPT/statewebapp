from django.contrib import admin

#SHM 06DEC18 1422EST
from .models import Voter

# Register your models here.
#SHM 06DEC18 1422EST
admin.site.register(Voter)

