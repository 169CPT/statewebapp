# This module will maintain various functions needed for things like validators, etc..


from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

def validpwd(value):
    if len(value) < 5:
        raise ValidationError(
            _('%(value)s must be at least 4 characters long'),
            params={'value': value},
        )