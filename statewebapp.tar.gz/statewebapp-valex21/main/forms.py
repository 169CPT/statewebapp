from django import forms
from main.models import Voter

class RegForm(forms.ModelForm):
    class Meta: 
        model = Voter
        fields = [ 'first_name', 'last_name', 'dob', 'ssnum', 'gender', 'birthcounty', 'homestreet', 'homecity', 'homestate', 'homezip', 'email', 'password', 'comments' ]
        #comment = forms.CharField(widget=forms.Textarea)