from django.shortcuts import render, redirect
from django.http import HttpResponse
from main.forms import RegForm
from django.views.decorators.csrf import csrf_exempt
from models import Voter
from django.views.generic import TemplateView
import sqlite3

def aboutview(request):
    #template_name = "about.html"
    return render(request, "main/about.html")

def test(request):
    return render(request, "main/home.html",
    {'h1Text':'MessageBox',
     'pText': 'Hello Sean'
    })
    #return HttpResponse("Hello Sean")
    
def landing(request):
    msgobj =     {'h1Text':"Welcome to Green Bay's Citizen self service portal",
     'pText': "Green Bay: Leading the way in cyber initiatives."
    }
    return render(request, "main/home.html", msgobj)

@csrf_exempt
def register(request):
    if request.method == 'POST':
       newRegForm = RegForm(request.POST)
       if newRegForm.is_valid():
           regData = Voter()
           regData = newRegForm.save()
           regData.save()
           return redirect('landing')
    else:
        newRegForm = RegForm()
    
    return render(request, 'main/register.html', {'regform':newRegForm})

@csrf_exempt
def citizenlogin(request):
    if request.method == 'GET':
        msgobj = {'h1Text':"Welcome to Green Bay's Citizen self service portal",
                  'pText': "Green Bay: Leading the way in cyber initiatives."
                 }
        return render(request, "main/citizenlogin.html", msgobj)
    elif request.method == 'POST':
        conn = sqlite3.connect("db.sqlite3")
        c = conn.cursor()
        sql = 'SELECT * FROM main_voter WHERE email = "%s" AND password = "%s"' % (request.POST.get('email'), request.POST.get('password'))
        records = c.execute(sql)
        record = records.fetchone()
        if record:
            # Ok, so we now have a sucessfull login so let us assign session variables to host
            # email and firstname of active account.
            request.session['activeuseremail'] = record[8]
            request.session['activeusername'] = record[1]
            return render(request, "main/home.html")
            #m = Member.objects.get(username=request.POST['username'])
            #if m.password == request.POST['password']:
            #   request.session['member_id'] = m.id
            #   return HttpResponse("You're logged in.")
        else:
            # Failed login so let us delete any session variables for active login if they do exist
            if 'activeuseremail' in request.session:
                del request.session['activeuseremail']
            if 'activeusername' in request.session:
                del request.session['activeusername']
            msgobj = {'h1Text':'Login Failure',
                      'pText': "Your username and password combo didn't match any current active users."
                     }
            return render(request, "main/citizenlogin.html", msgobj)

     

'''
@post
def register(request):
    newRegForm = RegForm(request.POST)
    if newRegForm.is_Valid():
       save_ok = newRegForm.save()
    return redirect('landing')
'''

    #return render(request, "main/register.html",
    #{'h1Text':"Voter Registration Page",
    # 'pText': "This page is monitored by CPT169, so if you are up to no-good you will quickly be discovered"
    #})
