# statewebapp
Django/Python web app with SQLite3 DB to track voters and tax deeds Django/Python web app with SQLite3 DB to track voters and tax deeds

| filename | description |
| ------ | ------ | 
| requirements.txt | pip freeze of the current dependencies for this version/release |
| statewebapp.service | a systemd service to be installed into /etc/systemd/system to allow systemctl of the web app |
| cifs.setup | directions on how to set up CIFS/SMB as client to connect to Windows FileServer with share. The share will be used to capture uploaded tax documents that uploaded via this web app |
| db.sqlite3 | This is the local SQL DB (Not accessible via socket/network) that is used to maintain the Citizen PII, to include voter reg info |
| git-pip.py | Script to allow download and install of pip for python2.7.  #python2 get-pip.py |
| valex21-{1-5}.csv | CVS files with 1000 names each that can be imported into the db.sqlite3 database. |

# Implementation Notes
1. pyhthon manage.py makemigrations   _this will make schema changes to SQL based on model changes_
1. python manage.oy migrate     _this will make the changes in the sqllite DB itself'
